﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace Millionaire
{
    public class Question
    {
        private string? text;
        private string[]? answer;
        private int rightIndex;

        public event PropertyChangedEventHandler? PropertyChanged;

        public string? Text { get => text; set => OnPropertyChanged(out text, value); }

        public string[]? Answer { get => answer; set => OnPropertyChanged(out answer, value); }

        public int RightIndex { get => rightIndex; set => OnPropertyChanged(out rightIndex, value); }

        private void OnPropertyChanged<T>(out T prop, T value, [CallerMemberName] string? propName = null)
        {
            prop = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propName));
        }
    }
}
