﻿using System.ComponentModel;
using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Markup;

namespace Millionaire
{
    public partial class MainWindow : Window
    {
        private Question question = new Question();
        private int questionStep = 1;

        public MainWindow()
        {
            InitializeComponent();
            DataContext = question;

            var obj = LoadQuestion($"Questions/question{questionStep}.json");

            if (obj != null)
            {
                question.Text = obj.Text;
                question.Answer = obj.Answer;
                question.RightIndex = obj.RightIndex;
            }
        }

        public Question LoadQuestion(string path)
        {
            var json = File.ReadAllText(path);
            return JsonSerializer.Deserialize<Question>(json)!;
        }

        public void InitializeData(Question question, Question obj)
        {
            question.Text = obj.Text;
            question.Answer = obj.Answer;
            question.RightIndex = obj.RightIndex;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (questionStep == 1)
            {
                var obj = LoadQuestion($"Questions/question{questionStep}.json");
                
                if (obj != null)
                {
                    InitializeData(question, obj);
                }

                ++questionStep;
            }
            else if(questionStep == 2)
            {
                var obj = LoadQuestion($"Questions/question{questionStep}.json");

                if (obj != null)
                {
                    InitializeData(question, obj);
                }

                ++questionStep;
            }
        }
    }
}
